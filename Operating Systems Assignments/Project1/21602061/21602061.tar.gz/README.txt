Notes on execution and use:
1) "make" command can be used to produce an executable "bilshell.o"
2) Use of the shell program is up to the specification given in the assignment.
3) "exit" command can be used to exit bilshell.

