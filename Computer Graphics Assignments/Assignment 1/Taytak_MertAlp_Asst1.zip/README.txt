Instructions to Compile:

- No compilation necessary.

Instructions to Run:

- Go into the 'Executable' directory.
- Open the file 'CityscapeGenerator.html' with a browser.
