/*
    Author: Mert Alp Taytak
    ID: 21602061

    JavaScript file for Assignment 3 of the course CS465.
*/

/*
    CONSTANTS and GLOBAL VARIABLES
*/

// WebGL object
var GL;

// Structure to access GL programs
const GL_PROGRAMS = {
    WIREFRAME: null,
    GOURAUD: null,
    PHONG: null
};

// Selections
var SELECTION_SHAPE;
var SELECTION_SHADER;
var SELECTION_MAPPING;

// Superquadric object parameters
const ETA_HIGHER = Math.PI / 2;
const ETA_LOWER = -Math.PI / 2;
const OMEGA_HIGHER = Math.PI;
const OMEGA_LOWER = -Math.PI;
var ETA_STEP;
var OMEGA_STEP;
var EPSILON_1;
var EPSILON_2;
var ALPHA_1;
var ALPHA_2;
var ALPHA_3;

// Buffers
var BUFFER_VERTICES;
var BUFFER_NORMALS;

// Buffer data
const DATA_VERTICES = [];
const DATA_NORMALS = [];

// Data locations
var LOC_VERTICES;
var LOC_NORMALS;

// Uniform data
var UNI_MODELVIEW;
var UNI_PROJECTION;

// Uniform locations
var LOC_MODELVIEW;
var LOC_PROJECTION;

// ModelView parameters
var MV_EYE = vec3(50.0, 10.0, 50.0);
const MV_AT = vec3(0.0, 0.0, 0.0);
const MV_UP = vec3(0.0, 1.0, 0.0);
var MV_RADIUS;
var MV_THETA;
var MV_PHI;

// Projection parameters
var PROJ_LEFT = -2;
var PROJ_RIGHT = 2;
var PROJ_BOTTOM = -2;
var PROJ_TOP = 2;
var PROJ_NEAR = -100;
var PROJ_FAR = 100;

// Set up program start
window.onload = initialize;

/**
 * Initializes WebGL, compiles shaders and sets up global variables.
 */
function initialize()
{
    // Call listeners first to initialize labels and global variables
    listener_shading();
    listener_mapping();
    listener_eta();
    listener_omega();
    listener_epsilon1();
    listener_epsilon2();
    listener_alpha1();
    listener_alpha2();
    listener_alpha3();

    // Get WebGL context
    const canvas = document.getElementById("gl_canvas");
    GL = canvas.getContext("webgl");

    if (GL === null) {
        alert("Unable to initialize WebGL.");
    }

    // Set some WebGL parameters
    GL.viewport(0, 0, canvas.width, canvas.height);
    GL.clearColor(0.95, 0.95, 0.95, 1.0);
    GL.enable(GL.DEPTH_TEST);
    GL.clear(GL.COLOR_BUFFER_BIT);

    // Compile shaders and programs
    var wireframe = initShaders(GL, "wireframe_v_shader", "wireframe_f_shader");
    var gouraud = initShaders(GL, "gouraud_v_shader", "gouraud_f_shader");
    var phong = initShaders(GL, "phong_v_shader", "phong_f_shader");

    // Write to the enum
    GL_PROGRAMS.WIREFRAME = wireframe;
    GL_PROGRAMS.GOURAUD = gouraud;
    GL_PROGRAMS.PHONG = phong;

    if (
        GL_PROGRAMS.WIREFRAME === null || 
        GL_PROGRAMS.GOURAUD === null || 
        GL_PROGRAMS.PHONG === null) {
            alert("One of the shaders could not be initialized.");
    }

    // Create buffers
    BUFFER_VERTICES = GL.createBuffer();
    BUFFER_NORMALS = GL.createBuffer();
}

/**
 * Renders the scene.
 */
function render()
{
    GL.clear(GL.COLOR_BUFFER_BIT | GL.DEPTH_BUFFER_BIT);

    // Delegate to other functions based on user selection
    if (SELECTION_SHADER == 0) // Wireframe
        render_wireframe();
    else if (SELECTION_SHADER == 1) // Gouraud
        render_gouraud();
    else // Phong
        render_phong();
}

/**
 * Renders the scene as a wireframe.
 */
function render_wireframe()
{
    // Select appropriate program
    GL.useProgram(GL_PROGRAMS.WIREFRAME);

    // Get locations of attributes and uniforms
    LOC_VERTICES = GL.getAttribLocation(GL_PROGRAMS.WIREFRAME, "vPos");
    LOC_MODELVIEW = GL.getUniformLocation(GL_PROGRAMS.WIREFRAME, "modelViewMatrix");
    LOC_PROJECTION = GL.getUniformLocation(GL_PROGRAMS.WIREFRAME, "projectionMatrix");

    // Generate vertices
    if (SELECTION_SHAPE == 0) // Ellipsoid
        ellipsoid_vertices();
    else
        toroid_vertices();

    // Bind buffer data
    GL.bindBuffer(GL.ARRAY_BUFFER, BUFFER_VERTICES);
    GL.bufferData(GL.ARRAY_BUFFER, flatten(DATA_VERTICES), GL.STATIC_DRAW);
    GL.vertexAttribPointer(LOC_VERTICES, 4, GL.FLOAT, false, 0, 0);
    GL.enableVertexAttribArray(LOC_VERTICES);

    // Calculate uniforms
    UNI_MODELVIEW = lookAt(MV_EYE, MV_AT, MV_UP);
    UNI_PROJECTION = ortho(PROJ_LEFT, PROJ_RIGHT, PROJ_BOTTOM, PROJ_TOP, PROJ_NEAR, PROJ_FAR);

    // Bind uniforms
    GL.uniformMatrix4fv(LOC_MODELVIEW, false, flatten(UNI_MODELVIEW));
    GL.uniformMatrix4fv(LOC_PROJECTION, false, flatten(UNI_PROJECTION));

    // Draw
    for (let i = 0; i < DATA_VERTICES.length; i += 3) {
        GL.drawArrays(GL.LINE_LOOP, i, 3);
    }
}

/*
    GENERATORS
*/

/**
 * Takes the given array and function, applies the given function over a range
 * of superquadric function parameters to populate the array.
 * @param {array} array 
 * @param {function} func 
 */
function generator(array, func)
{
    // Clear array
    array.length = 0;

    // Will be used to hold 4 points that will turn into 2 triangles
    let lowLeft, lowRight, upRight, upLeft;

    for (let eta = ETA_LOWER + 1*ETA_STEP; eta <= ETA_HIGHER; eta += 1*ETA_STEP) {
        let etaPrev = eta - ETA_STEP;

        for (let omega = OMEGA_LOWER; omega < OMEGA_HIGHER - OMEGA_STEP; omega += 1*OMEGA_STEP) {
            let omegaNext = omega + 1*OMEGA_STEP;

            lowLeft = func(eta, omega);
            lowRight = func(eta, omegaNext);
            upRight = func(etaPrev, omegaNext);
            upLeft = func(etaPrev, omega);

            // Push triangles
            array.push(lowLeft);
            array.push(lowRight);
            array.push(upRight);
            array.push(lowLeft);
            array.push(upRight);
            array.push(upLeft);
        }

        // Connect last column to first column
        // Shift right to left for efficiency
        lowLeft = lowRight;
        upLeft = upRight;

        // Calculate first column
        lowRight = func(eta, OMEGA_LOWER);
        upRight = func(etaPrev, OMEGA_LOWER);

        // Push triangles
        array.push(lowLeft);
        array.push(lowRight);
        array.push(upRight);
        array.push(lowLeft);
        array.push(upRight);
        array.push(upLeft);
    }
}

/**
 * Parametric surface equation for superellipsoids.
 * @param {number} eta
 * @param {number} omega
 */
function ellipsoid_surface(eta, omega)
{
    return vec4(
        ALPHA_1 * Math.pow(Math.cos(eta), EPSILON_1) * Math.pow(Math.cos(omega), EPSILON_2),
        ALPHA_2 * Math.pow(Math.cos(eta), EPSILON_1) * Math.pow(Math.sin(omega), EPSILON_2),
        ALPHA_3 * Math.pow(Math.sin(eta), EPSILON_1),
        1.0
    );
}

/**
 * Parametric normal vector equation for superellipsoids.
 * @param {number} eta 
 * @param {number} omega 
 */
function ellipsoid_normal(eta, omega)
{

}

function ellipsoid_vertices()
{
    generator(DATA_VERTICES, ellipsoid_surface);
}

function ellipsoid_normals()
{
   generator(DATA_NORMALS, ellipsoid_normal);
}

function toroid_vertices()
{
   // Clear array
   DATA_VERTICES.length = 0;
}

function toroid_normals()
{
    // Clear array
    DATA_VERTICES.length = 0;
}

/*
    LISTENERS
*/

function listener_render()
{
    // Get the selections for step, shape, shader and mapping
    listener_eta();
    listener_omega();
    listener_shape();
    listener_shading();
    listener_mapping();

    // Finally, render the scene
    render();
}

function listener_shape()
{
    var radios = document.getElementsByName("radio_shape");

    for (let i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            SELECTION_SHAPE = i;
            break;  // Only one can be checked
        }
    }
}

function listener_shading()
{
    var radios = document.getElementsByName("radio_shader");

    for (let i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            SELECTION_SHADER = i;
            break;  // Only one can be checked
        }
    }
}

function listener_mapping()
{
    var radios = document.getElementsByName("radio_mapping");

    for (let i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            SELECTION_MAPPING = i;            
            break; // Only one can be checked
        }
    }
}

function listener_eta()
{
    ETA_STEP = document.getElementById("slider_eta").value;
    document.getElementById("val_eta").innerHTML = ETA_STEP;
}

function listener_omega()
{
    OMEGA_STEP = document.getElementById("slider_omega").value;
    document.getElementById("val_omega").innerHTML = OMEGA_STEP;
}

function listener_epsilon1()
{
    EPSILON_1 = document.getElementById("slider_epsilon1").value;
    document.getElementById("val_epsilon1").innerHTML = EPSILON_1;
}

function listener_epsilon2()
{
    EPSILON_2 = document.getElementById("slider_epsilon2").value;
    document.getElementById("val_epsilon2").innerHTML = EPSILON_2;
}

function listener_alpha1()
{
    ALPHA_1 = document.getElementById("slider_alpha1").value;
    document.getElementById("val_alpha1").innerHTML = ALPHA_1;
}

function listener_alpha2()
{
    ALPHA_2 = document.getElementById("slider_alpha2").value;
    document.getElementById("val_alpha2").innerHTML = ALPHA_2;
}

function listener_alpha3()
{
    ALPHA_3 = document.getElementById("slider_alpha3").value;
    document.getElementById("val_alpha3").innerHTML = ALPHA_3;
}