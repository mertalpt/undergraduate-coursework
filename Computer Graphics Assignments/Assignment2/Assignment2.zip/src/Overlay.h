#ifndef __OVERLAY_H_
#define __OVERLAY_H_

#include "IDrawable.h"

/*
    Class used to act as a user interface overlay.
*/
class Overlay: public IDrawable
{
public:
    Overlay();
    ~Overlay();

private:
};

#endif // Define __OVERLAY_H_
