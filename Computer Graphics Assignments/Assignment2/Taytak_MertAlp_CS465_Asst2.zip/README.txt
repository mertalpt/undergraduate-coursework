Compile Instructions:
- Run "make" from the terminal to create an executable "Alpine.exe".
- Requires OpenGL version 4.6, other OpenGL 4.* versions may work.
- Requires OpenGL, GLEW, GLFW libraries in the include path.

Comments:
- Animations, models and textures are not properly implemented.
- However, there are more than 2.3k lines of code.
Most of the OpenGL related calls are automated by functions.
