Instructions:
- Import the FinalProject folder as a GAMA project. Find the model file and run the single experiment.
