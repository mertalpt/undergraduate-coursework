/**
 * Class representing a gravitational field
 * 
 * @author Mert Alp TAYTAK
 * @version 07/05/2017
 */

// IMPORTS

import java.util.ArrayList;

// CLASS

public class GravitationalField extends Field
{
   // FIELDS
   
   private final static double GRAVITATIONAL_CONSTANT = 6.67384e-11;
   
   // PROPERTIES
   
   private ArrayList<Particle> particles;
   
   // CONSTRUCTORS
   
   public GravitationalField(int width, int heigth, double sensitivity)
   {
      super(width, heigth, sensitivity);
      
      particles = new ArrayList<Particle>();
   }
   
   // METHODS
   
   /**
    * Adds a particle to the gravitational field
    * 
    * @param particle Particle to add
    */
   public void addParticle(Particle particle)
   {
      particles.add(particle);
   }
   
   /**
    * Removes particle
    * 
    * @param particle Particle to remove
    */
   public void removeParticle(Particle particle)
   {
      // To do
   }
   
   /**
    * Calculates field strength based on listed particles and updates the field 
    */
   public void update()
   {
      // To do
   }
   
   
}